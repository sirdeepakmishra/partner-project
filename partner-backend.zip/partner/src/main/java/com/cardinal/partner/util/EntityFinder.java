package com.cardinal.partner.util;

import javax.transaction.Transactional;

import org.springframework.stereotype.Component;

@Component
@Transactional
public class EntityFinder {

}
