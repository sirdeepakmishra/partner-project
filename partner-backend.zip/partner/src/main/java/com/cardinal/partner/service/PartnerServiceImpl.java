package com.cardinal.partner.service;

import java.sql.Timestamp;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cardinal.partner.dto.PartnerRequestResponse;
import com.cardinal.partner.model.Partner;
import com.cardinal.partner.repository.PartnerRepository;
import com.cardinal.partner.util.BeanMapperUtil;

@Service
@Transactional
public class PartnerServiceImpl implements PartnerService {

	@Autowired
	PartnerRepository partnerRepository;

	@Autowired
	BeanMapperUtil beanMapperUtil;

	@Override
	public List<PartnerRequestResponse> findAllPartner() {
		return beanMapperUtil.mapPartners(partnerRepository.findByIsDeleted(false));
	}

	@Override
	public PartnerRequestResponse findPartnerById(Long partnerId) {
		return beanMapperUtil.mapPartner(
				partnerRepository.findById(partnerId).isPresent() ? partnerRepository.findById(partnerId).get() : null);
	}

	@Override
	public PartnerRequestResponse savePartner(PartnerRequestResponse partnerRequest) {
		Partner partner = beanMapperUtil.map(partnerRequest, Partner.class);
		partner.setIsDeleted(false);
		return beanMapperUtil.mapPartner(partnerRepository.save(partner));
	}

	@Override
	public PartnerRequestResponse modifyPartner(PartnerRequestResponse partnerRequest) {
		Partner partnerNew = null;
		Partner partner = partnerRepository.findById(partnerRequest.getPartnerId()).isPresent()
				? partnerRepository.findById(partnerRequest.getPartnerId()).get()
				: null;
		if(partner != null) {
			partnerNew = beanMapperUtil.map(partnerRequest, Partner.class);
			partnerNew.setIsDeleted(partner.getIsDeleted());
			partnerNew.setCreationTimestamp(partner.getCreationTimestamp());
			partnerNew.setModificationTimestamp(new Timestamp(System.currentTimeMillis()));
			partnerRepository.save(partnerNew);
		}
		return beanMapperUtil.mapPartner(partnerNew);
	}

	@Override
	public PartnerRequestResponse deletePartnerById(Long partnerId) {
		Partner partner = partnerRepository.findById(partnerId).isPresent()
				? partnerRepository.findById(partnerId).get()
				: null;
		if (partner != null) {
			partner.setIsDeleted(true);
		}
		partnerRepository.save(partner);
		return beanMapperUtil.mapPartner(partner);
	}

}
