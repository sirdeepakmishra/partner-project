package com.cardinal.partner.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cardinal.partner.dto.PartnerRequestResponse;
import com.cardinal.partner.service.PartnerService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/partner")
public class PartnerController {

	@Autowired
	PartnerService partnerService;

	@CrossOrigin("*")
	@ApiOperation(value = "Get List of all partners")
	@GetMapping(path = "", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<List<PartnerRequestResponse>> findAllPartner() {
		return new ResponseEntity<List<PartnerRequestResponse>>(partnerService.findAllPartner(), HttpStatus.OK);
	}

	@CrossOrigin("*")
	@ApiOperation(value = "Get partner by User id (PK)")
	@GetMapping(path = "/{partnerId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<PartnerRequestResponse> getPartnerById(@PathVariable Long partnerId) {
		return new ResponseEntity<PartnerRequestResponse>(partnerService.findPartnerById(partnerId), HttpStatus.OK);
	}

	@CrossOrigin("*")
	@ApiOperation(value = "save partner")
	@PostMapping(produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<PartnerRequestResponse> savePartner(
			@RequestBody PartnerRequestResponse partnerRequestResponse) {
		return new ResponseEntity<PartnerRequestResponse>(partnerService.savePartner(partnerRequestResponse),
				HttpStatus.CREATED);
	}

	@CrossOrigin("*")
	@ApiOperation(value = "modify partner")
	@PutMapping(produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<PartnerRequestResponse> modifyPartner(
			@RequestBody PartnerRequestResponse partnerRequestResponse) {
		return new ResponseEntity<PartnerRequestResponse>(partnerService.modifyPartner(partnerRequestResponse),
				HttpStatus.OK);
	}

	@CrossOrigin("*")
	@ApiOperation(value = "delete partner")
	@DeleteMapping(path = "/{partnerId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<PartnerRequestResponse> deletePartner(@PathVariable Long partnerId) {
		return new ResponseEntity<PartnerRequestResponse>(partnerService.deletePartnerById(partnerId),
				HttpStatus.ACCEPTED);
	}

}
