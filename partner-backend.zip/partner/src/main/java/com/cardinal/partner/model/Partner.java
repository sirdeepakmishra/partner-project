package com.cardinal.partner.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "partner")
public class Partner implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long partnerId;
	private String name;
	private String salutation;
	private String currentLocation;
	private String linkedinProfile;
	private String contactNumber;
	private String emailId;
	private String skypeId;
	private String address;
	private String profileSynopsis;
	@Column(name = "business_potential_a")
	private String businessPotentialA;
	@Column(name = "business_potential_b")
	private String businessPotentialB;
	@Column(name = "business_potential_c")
	private String businessPotentialC;
	@Column(name = "business_potential_d")
	private String businessPotentialD;
	@Column(name = "business_potential_e")
	private String businessPotentialE;
	@Column(name = "business_potential_f")
	private String businessPotentialF;
	@Column(name = "business_potential_g")
	private String businessPotentialG;
	@Column(name = "business_potential_h")
	private String businessPotentialH;
	@Column(name = "business_potential_i")
	private String businessPotentialI;
	@Column(name = "business_potential_j")
	private String businessPotentialJ;
	@Column(name = "business_potential_k")
	private String businessPotentialK;

	@CreationTimestamp
	private Timestamp creationTimestamp;
	@UpdateTimestamp
	private Timestamp modificationTimestamp;
	private Boolean isDeleted = false;

	public Partner() {
		super();
	}

	public Long getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSalutation() {
		return salutation;
	}

	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	public String getCurrentLocation() {
		return currentLocation;
	}

	public void setCurrentLocation(String currentLocation) {
		this.currentLocation = currentLocation;
	}

	public String getLinkedinProfile() {
		return linkedinProfile;
	}

	public void setLinkedinProfile(String linkedinProfile) {
		this.linkedinProfile = linkedinProfile;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getSkypeId() {
		return skypeId;
	}

	public void setSkypeId(String skypeId) {
		this.skypeId = skypeId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getProfileSynopsis() {
		return profileSynopsis;
	}

	public void setProfileSynopsis(String profileSynopsis) {
		this.profileSynopsis = profileSynopsis;
	}

	public String getBusinessPotentialA() {
		return businessPotentialA;
	}

	public void setBusinessPotentialA(String businessPotentialA) {
		this.businessPotentialA = businessPotentialA;
	}

	public String getBusinessPotentialB() {
		return businessPotentialB;
	}

	public void setBusinessPotentialB(String businessPotentialB) {
		this.businessPotentialB = businessPotentialB;
	}

	public String getBusinessPotentialC() {
		return businessPotentialC;
	}

	public void setBusinessPotentialC(String businessPotentialC) {
		this.businessPotentialC = businessPotentialC;
	}

	public String getBusinessPotentialD() {
		return businessPotentialD;
	}

	public void setBusinessPotentialD(String businessPotentialD) {
		this.businessPotentialD = businessPotentialD;
	}

	public String getBusinessPotentialE() {
		return businessPotentialE;
	}

	public void setBusinessPotentialE(String businessPotentialE) {
		this.businessPotentialE = businessPotentialE;
	}

	public String getBusinessPotentialF() {
		return businessPotentialF;
	}

	public void setBusinessPotentialF(String businessPotentialF) {
		this.businessPotentialF = businessPotentialF;
	}

	public String getBusinessPotentialG() {
		return businessPotentialG;
	}

	public void setBusinessPotentialG(String businessPotentialG) {
		this.businessPotentialG = businessPotentialG;
	}

	public String getBusinessPotentialH() {
		return businessPotentialH;
	}

	public void setBusinessPotentialH(String businessPotentialH) {
		this.businessPotentialH = businessPotentialH;
	}

	public String getBusinessPotentialI() {
		return businessPotentialI;
	}

	public void setBusinessPotentialI(String businessPotentialI) {
		this.businessPotentialI = businessPotentialI;
	}

	public String getBusinessPotentialJ() {
		return businessPotentialJ;
	}

	public void setBusinessPotentialJ(String businessPotentialJ) {
		this.businessPotentialJ = businessPotentialJ;
	}

	public String getBusinessPotentialK() {
		return businessPotentialK;
	}

	public void setBusinessPotentialK(String businessPotentialK) {
		this.businessPotentialK = businessPotentialK;
	}

	public Timestamp getCreationTimestamp() {
		return creationTimestamp;
	}

	public void setCreationTimestamp(Timestamp creationTimestamp) {
		this.creationTimestamp = creationTimestamp;
	}

	public Timestamp getModificationTimestamp() {
		return modificationTimestamp;
	}

	public void setModificationTimestamp(Timestamp modificationTimestamp) {
		this.modificationTimestamp = modificationTimestamp;
	}

	public Boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

}
