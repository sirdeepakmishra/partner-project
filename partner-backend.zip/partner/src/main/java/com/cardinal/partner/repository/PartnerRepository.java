package com.cardinal.partner.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cardinal.partner.model.Partner;

public interface PartnerRepository extends JpaRepository<Partner, Long> {

	public List<Partner> findByIsDeleted(Boolean isDeleted);

}