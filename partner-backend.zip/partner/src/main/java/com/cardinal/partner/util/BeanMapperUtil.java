package com.cardinal.partner.util;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.dozer.DozerBeanMapper;
import org.springframework.stereotype.Component;

import com.cardinal.partner.dto.PartnerRequestResponse;
import com.cardinal.partner.model.Partner;

@Component
@Transactional
public class BeanMapperUtil extends DozerBeanMapper {

	public PartnerRequestResponse mapPartner(Partner partner) {
		PartnerRequestResponse partnerReqRes = null;
		if(partner != null) {
			partnerReqRes = this.map(partner, PartnerRequestResponse.class);
			partnerReqRes.setCreationTimestampStr(PartnerUtil.timeStampFormat.format(partner.getCreationTimestamp()));
			partnerReqRes.setModificationTimestampStr(partner.getCreationTimestamp() != null
					? PartnerUtil.timeStampFormat.format(partner.getCreationTimestamp())
					: null);
		}
		return partnerReqRes;
	}

	public List<PartnerRequestResponse> mapPartners(List<Partner> partners) {
		List<PartnerRequestResponse> partnerRequestResponses = new ArrayList<PartnerRequestResponse>();
		if (partners != null && !partners.isEmpty()) {
			for (Partner partnerObj : partners) {
				partnerRequestResponses.add(this.mapPartner(partnerObj));
			}
		}
		return partnerRequestResponses;
	}

}
