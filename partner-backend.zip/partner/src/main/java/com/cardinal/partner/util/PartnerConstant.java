package com.cardinal.partner.util;

public class PartnerConstant {
}
