package com.cardinal.partner.service;

import java.util.List;

import com.cardinal.partner.dto.PartnerRequestResponse;

public interface PartnerService {

	public List<PartnerRequestResponse> findAllPartner();

	public PartnerRequestResponse findPartnerById(Long partnerId);

	public PartnerRequestResponse savePartner(PartnerRequestResponse partnerRequest);

	public PartnerRequestResponse modifyPartner(PartnerRequestResponse partnerRequest);

	public PartnerRequestResponse deletePartnerById(Long partnerId);

}
