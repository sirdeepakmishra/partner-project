package com.cardinal.partner.util;

import java.text.SimpleDateFormat;

public class PartnerUtil {

	public static SimpleDateFormat timeStampFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm");

}
