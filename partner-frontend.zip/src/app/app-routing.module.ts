import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PartnerRegistrationComponent } from './partner-registration/partner-registration.component';
import { PartnerListingComponent } from './partner-listing/partner-listing.component';

const routes: Routes = [
  {path: 'partner-registration', component: PartnerRegistrationComponent},
  {path: 'partner-listing', component: PartnerListingComponent},
  {path: '', redirectTo: '/partner-registration', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
