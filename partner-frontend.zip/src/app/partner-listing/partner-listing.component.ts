import { Component, OnInit } from '@angular/core';
declare const $: any;

@Component({
  selector: 'app-partner-listing',
  templateUrl: './partner-listing.component.html',
  styleUrls: ['./partner-listing.component.css']
})
export class PartnerListingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
      $('#myTable').DataTable();
  }

}
